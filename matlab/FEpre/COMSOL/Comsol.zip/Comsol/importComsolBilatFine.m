function mesh = importComsolBilatFine(saved)
% clear all; clc; close all;
if saved
  load mesh;
else

  ele = importdata('fine\elementsFine.txt');
  xy = importdata('fine\nodesFine.txt').'*1e-3;
  elab = importdata('fine\elabFine.txt').';
  spig2 = importdata('fine\edgesFine.txt').'+1;
  nlabSpig = importdata('fine\nodeLabFine.txt').';
  ele = ele.';
  ele(2:4,:) = ele+1;
  ele(1,:) = 3;
  elab(elab > 1)=2;
  tmp = spig2(2,:) ;
  spig2(2,:) = spig2(1,:);
  spig2(1,:) = tmp;
  nlab = zeros(1,length(xy));
  nlab(spig2(1,:)) = nlabSpig(1,:);
  nlab(spig2(2,:)) = nlabSpig(2,:);
  for i=2:2:12
    nlab(nlab == i) = 1;
  end
  nlab(nlab > 1) = 2;
  idx = [290 746 1099 1480 1877];
  nlab(idx) = 1;
  idx = [247 2052];
  nlab(idx) = 0;

  nlab(xy(1,:) < min(xy(1,:))+1e-5 ) = 11;
  nlab(xy(1,:) > max(xy(1,:))-1e-5 ) = 12;

  mesh.ele = ele;
  mesh.node = xy;
  mesh.elab = elab;
  mesh.spig2 = spig2;
  mesh.nlab = nlab;

  mesh.NNODE = length(xy);
  mesh.NELE = length(ele);
  save mesh mesh;
end

return

figure;
trimesh(mesh.ele(2:4,:).', mesh.node(1,:), mesh.node(2,:),...
  'color','k');%, 'linewidth', 2)
title('Elements');
axis equal; axis tight; hold on;
text( (mesh.node(1,mesh.ele(2,:)) + mesh.node(1,mesh.ele(3,:)) + ...
  mesh.node(1,mesh.ele(4,:)) )/3, ...
  (mesh.node(2,mesh.ele(2,:)) + mesh.node(2,mesh.ele(3,:)) + ...
  mesh.node(2,mesh.ele(4,:)) )/3, ...
  num2str((1:length(mesh.elab)).' ),'color','b','FontSize',8, ...
  'HorizontalAlignment', 'center');
% text( (mesh.node(1,mesh.spig2(1,:)) + mesh.node(1,mesh.spig2(2,:)))/2, ...
%     (mesh.node(2,mesh.spig2(1,:)) + mesh.node(2,mesh.spig2(2,:)))/2, ...
%     num2str((1:length(mesh.spig2)).'),'color','b','FontSize',8, ...mesh.slab.'
%     'HorizontalAlignment', 'center');
geom = plot2dGeom('bilatFilter');
figure;hold on;
% line(geom.x(geom.t.'),geom.y(geom.t.'),'color','k'); 
plot(mesh.node(1,:), mesh.node(2,:), 'b.');%, 'markersize', 20);
text( mesh.node(1,:), mesh.node(2,:), num2str(mesh.nlab.'), ...
  'FontSize',8, 'HorizontalAlignment', 'center');
title('Nodes'); axis equal; axis tight; 

figure
plot(mesh.node(1,:), mesh.node(2,:), 'b.');%, 'markersize', 20);
title('Nodes');
axis equal; axis tight; hold on;
text( mesh.node(1,:), mesh.node(2,:), num2str((1:length(nlab)).'), ...
  'FontSize',10, 'HorizontalAlignment', 'center');
